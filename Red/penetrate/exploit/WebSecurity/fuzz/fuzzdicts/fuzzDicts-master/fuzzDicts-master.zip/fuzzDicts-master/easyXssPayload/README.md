
# easyXssPayload


# 食用指南 How To Use It

-------

* 如非本地测试不建议拿burp一条一条的写到目标系统，因为删除麻烦。
* 相比fork更建议star，因为这个Payload打算每隔一段时间就更新一下，确保其时效性。
* 如无字节数限制建议手工一次插入500条进行测试，推荐火狐浏览器，有些浏览器(Safari)扛不住一次性渲染那么多标签，贼卡。

核心文件：[easyXssPayload.txt](https://github.com/TheKingOfDuck/easyXssPayload/blob/master/easyXssPayload.txt)

基本用法：[浅析一种简单暴力的Xss Fuzz手法](https://xz.aliyun.com/t/4985)

-------

## 杠精我日你全家 Hater Mother Fuck




